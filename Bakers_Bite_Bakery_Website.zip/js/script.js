document.addEventListener("DOMContentLoaded", function () {
  const cartCount = document.getElementById("cart-count");
  const summary = document.getElementById("order-summary");
  const filterButtons = document.querySelectorAll(".filter-btn");
  const products = document.querySelectorAll(".product-item");
  const cart = [];

  document.getElementById("year").textContent = new Date().getFullYear();

  document.querySelectorAll(".add-btn").forEach(button => {
    button.addEventListener("click", function () {
      const name = this.dataset.name;
      const price = Number(this.dataset.price);
      cart.push({ name, price });
      cartCount.textContent = cart.length;
      const total = cart.reduce((sum, item) => sum + item.price, 0);
      const names = cart.map(item => item.name).join(", ");
      summary.textContent = `Added: ${names} | Items: ${cart.length} | Estimated total: Rs. ${total.toLocaleString("en-PK")}`;
      this.innerHTML = "Added to order ✓";
      this.classList.add("added");
      setTimeout(() => { this.innerHTML = 'Add to order <span>+</span>'; this.classList.remove("added"); }, 1200);
    });
  });

  filterButtons.forEach(button => {
    button.addEventListener("click", function () {
      filterButtons.forEach(btn => btn.classList.remove("active"));
      this.classList.add("active");
      const category = this.dataset.filter;
      products.forEach(product => {
        product.style.display = category === "all" || product.dataset.category === category ? "" : "none";
      });
    });
  });

  document.getElementById("contact-form").addEventListener("submit", function (event) {
    event.preventDefault();
    const name = document.getElementById("name").value.trim();
    const message = document.getElementById("form-message");
    if (!name) return;
    message.textContent = `Thank you, ${name}! Your message has been noted. (Demo form — connect a backend to receive messages.)`;
    this.reset();
  });

  const topButton = document.getElementById("back-to-top");
  window.addEventListener("scroll", () => topButton.classList.toggle("show", window.scrollY > 450));
  topButton.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

  document.querySelectorAll(".navbar a").forEach(link => {
    link.addEventListener("click", () => {
      const nav = document.getElementById("mainNav");
      if (nav.classList.contains("show") && window.bootstrap) {
        bootstrap.Collapse.getOrCreateInstance(nav).hide();
      }
    });
  });
});