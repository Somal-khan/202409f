BAKERS BITE BAKERY WEBSITE
===========================

Files:
- index.html       Main website
- css/style.css    Custom styling
- js/script.js     Filters, demo cart, contact form message and back-to-top

HOW TO RUN:
1. Extract the ZIP folder.
2. Open the extracted folder in Visual Studio Code.
3. Open index.html.
4. Right-click index.html and choose "Open with Live Server" (if Live Server extension is installed),
   or double-click index.html to open it in your browser.
5. Internet is required for Bootstrap CDN, Google Fonts and online bakery photos.

CUSTOMIZE BEFORE SUBMISSION:
- Replace the bakery name, address, phone number and email with your own project details.
- Replace sample customer reviews and prices if needed.
- Add your team names / APTECH details if your instructor requires them.

NOTE:
This is a front-end academic demo. The order cart is a browser-side demo only, and the contact
form displays a confirmation message; it does not send orders or emails. A backend/database
would be needed for real order processing.
